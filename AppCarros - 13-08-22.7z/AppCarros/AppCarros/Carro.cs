﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace AppCarros
{
    internal class Carro
    {
        public int ID { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Km { get; set; }
        public string Descrição { get; set; }
        public string Classificação { get; set; }
        public string Estado { get; set; }
        public string Quantidade { get; set; }
        public DateTime Cadastro { get; set; }

        public List<Carro> listacarro()
        {
            List<Carro> li = new List<Carro>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand(); ;
            cmd.CommandText = "SELECT * FROM Carro";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Carro u = new Carro();
                u.ID = (int)dr["Id"];
                u.Marca = dr["marca"].ToString();
                u.Modelo = dr["modelo"].ToString();
                u.Km = dr["km"].ToString();
                u.Descrição = dr["descricao"].ToString();
                u.Classificação = dr["classificacao"].ToString();
                u.Classificação = dr["estado"].ToString();
                u.Classificação = dr["quantidade"].ToString();
                u.Cadastro = Convert.ToDateTime(dr["cadastro"]);

                li.Add(u);
            }
            return li;
        }
        public void Inserir(string marca, string modelo, string km, string descricao, string classificacao, string estado, string quantidade, DateTime cadastro)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO Carro(marca,modelo,km,descricao,classificacao,cadastro,estado,quantidade) VALUES ('" + marca + "','" + modelo + "','" + km + "','" + descricao + "','" + classificacao + "',Convert(DateTime,'" + cadastro + "',103),'" + estado + "','" + quantidade + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Localiza(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Carro WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Marca = dr["marca"].ToString();
                Modelo = dr["modelo"].ToString();
                Km = dr["km"].ToString();
                Descrição = dr["descricao"].ToString();
                Classificação = dr["classificacao"].ToString();
                Classificação = dr["estado"].ToString();
                Classificação = dr["quantidade"].ToString();
                Cadastro = Convert.ToDateTime(dr["cadastro"]);
            }
        }

        public void Atualizar(int id,string marca, string modelo, string km, string descricao, string classificacao, string estado, string quantidade, DateTime cadastro)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE Carro SET marca='" + marca + "',modelo='" + modelo + "',km='" + km + "',descricao='" + descricao + "',classificacao='" + classificacao + "',cadastro=Convert(DateTime,'" + cadastro + "',103),estado='" + estado + "',quantidade='" + quantidade + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM Carro WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}